# CraftStory AI — Website demo + online marketplace setup

CraftStory AI is a responsive Vietnamese handicrafts storefront with six interface languages, currency conversion, a seller studio, media uploads, and a buyer-facing product catalog.

## Run the demo locally

1. Open `index.html` in Chrome, Safari, Edge, or Firefox.
2. Register a demo account as a **customer** or **seller**.
3. Sign in as a seller, add a product, upload photos/videos, create a sample promotional draft, and publish.
4. Choose a language in the top-right menu to see the price in its mapped currency.

### Currency mapping

| Interface language | Display currency | Code |
|---|---|---|
| Tiếng Việt | Vietnamese dong | VND |
| 中文（简体） | Chinese yuan | CNY |
| 한국어 | South Korean won | KRW |
| English | US dollar (international default) | USD |
| Français | Euro | EUR |
| ភាសាខ្មែរ | Cambodian riel | KHR |

Product prices are stored internally in USD, then converted for display based on the language selected by the visitor. The seller's price input uses the currently selected language's currency and converts that amount to USD when publishing. Exchange rates are fetched from ExchangeRate-API's open endpoint when available; the page uses fallback estimates if the request fails. Rates are reference estimates, not payment or bank quotes. The source attribution is shown in the footer.

## Important: enable a shared online marketplace

Out of the box, this is a demo and saves accounts/products to the current browser only. **For sellers and buyers on different devices to see the same products, connect the site to a shared backend.** This project includes a Supabase integration and SQL setup file.

### 1. Create a Supabase project

1. Create a project in Supabase and wait for the database to finish provisioning.
2. Open **SQL Editor** in the Supabase dashboard.
3. Open `supabase-setup.sql`, copy the complete contents, paste into SQL Editor, and run it. It creates the profiles/products tables, row-level security policies, public media bucket, 20 MB bucket limit, and Realtime publication membership.
4. If the Storage global file-size limit is lower than 20 MB, open **Storage settings** and set the global limit to at least 20 MB. The bucket-level limit remains 20 MB.
5. In the project's API settings, copy the **Project URL** and the browser-safe **publishable key** (or legacy `anon` key).

### 2. Add the project URL/key to the website

Open `index.html` in a text editor and find these two lines near the top of the main script:

```js
const SUPABASE_URL='YOUR_SUPABASE_PROJECT_URL';
const SUPABASE_ANON_KEY='YOUR_SUPABASE_PUBLISHABLE_OR_ANON_KEY';
```

Replace the first value with your Supabase Project URL and the second with the project's **publishable/anon key**. Save the file. Do **not** put a `service_role` key or any secret key in this public website.

### 3. Publish on GitHub Pages

1. Create a GitHub repository and upload `index.html` to its root. Keep the URL/key configuration in the file.
2. Upload `supabase-setup.sql` and this README too, so the project is easy to maintain.
3. In the repository, open **Settings → Pages**; choose **Deploy from a branch**, branch `main`, folder `/ (root)`, then save.
4. Open the GitHub Pages URL. Register an account as **Seller** from one browser/device and publish a product. Open the same site from another browser/device and the new product will appear in the product catalog.
5. If email confirmation is enabled for Supabase Auth, confirm the registration email before signing in.

## Upload rules

- Up to **5 image/video files per product**.
- Each file must be **20 MB or smaller**. The browser validates each file, and the Supabase storage bucket is configured with a 20 MB per-file limit.
- The browser accepts image/video MIME types; the bucket restricts uploads to common image and video formats.
- The current upload uses the Supabase Storage standard-upload API. Supabase recommends resumable uploads for better reliability for files above 6 MB; switch to a TUS resumable upload flow before using this for frequent larger videos.

## Technical limitations before commercial use

- The online shared marketplace requires a Supabase project and the setup steps above. Without credentials, the site remains in local demo mode.
- Supabase Auth is used only when the project URL/key are configured. In local demo mode, demo accounts are browser-local and are not secure; use fake test passwords only.
- The AI-style promotional copy generator uses multilingual illustrative templates. It is not connected to a real AI service yet.
- This is not a full Shopee/Amazon replacement: it has no checkout, payment processing, delivery tracking, refunds, moderation workflow, seller verification, or production monitoring.
- Public product photos/videos in the `craft-media` bucket are accessible to anyone with their public URLs. Do not upload private content.
