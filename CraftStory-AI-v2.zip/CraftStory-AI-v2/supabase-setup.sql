-- CraftStory AI: shared online marketplace schema
-- Run this entire script in Supabase Dashboard -> SQL Editor.
-- Do not put a service_role/secret key in index.html.

create table if not exists public.profiles (
  id uuid primary key references auth.users(id) on delete cascade,
  display_name text not null default 'CraftStory user',
  role text not null default 'user' check (role in ('user', 'seller')),
  created_at timestamptz not null default now()
);

create or replace function public.craftstory_handle_new_user()
returns trigger
language plpgsql
security definer
set search_path = public
as $$
begin
  insert into public.profiles (id, display_name, role)
  values (
    new.id,
    coalesce(nullif(new.raw_user_meta_data->>'name', ''), split_part(new.email, '@', 1), 'CraftStory user'),
    case when new.raw_user_meta_data->>'role' = 'seller' then 'seller' else 'user' end
  )
  on conflict (id) do nothing;
  return new;
end;
$$;

drop trigger if exists craftstory_on_auth_user_created on auth.users;
create trigger craftstory_on_auth_user_created
after insert on auth.users
for each row execute procedure public.craftstory_handle_new_user();

create table if not exists public.products (
  id uuid primary key default gen_random_uuid(),
  seller_id uuid not null references auth.users(id) on delete cascade,
  seller_name text not null,
  name text not null,
  category text not null default 'other',
  origin text not null default '',
  description text not null,
  promo_copy text not null default '',
  price_usd numeric(12,2) not null default 0 check (price_usd >= 0),
  media jsonb not null default '[]'::jsonb,
  icon text not null default '🧵',
  created_at timestamptz not null default now()
);

create index if not exists products_created_at_idx on public.products (created_at desc);
create index if not exists products_seller_id_idx on public.products (seller_id);

alter table public.profiles enable row level security;
alter table public.products enable row level security;

grant usage on schema public to anon, authenticated;
grant select on public.profiles to authenticated;
grant select on public.products to anon, authenticated;
grant insert, update, delete on public.products to authenticated;

-- Profiles are created by the auth trigger. Clients cannot self-promote by updating their role.
drop policy if exists "Users can read their own profile" on public.profiles;
create policy "Users can read their own profile"
on public.profiles for select to authenticated
using (id = auth.uid());

drop policy if exists "Products are public to read" on public.products;
create policy "Products are public to read"
on public.products for select to anon, authenticated
using (true);

drop policy if exists "Sellers can insert their own products" on public.products;
create policy "Sellers can insert their own products"
on public.products for insert to authenticated
with check (
  seller_id = auth.uid()
  and exists (select 1 from public.profiles p where p.id = auth.uid() and p.role = 'seller')
);

drop policy if exists "Sellers can update their own products" on public.products;
create policy "Sellers can update their own products"
on public.products for update to authenticated
using (
  seller_id = auth.uid()
  and exists (select 1 from public.profiles p where p.id = auth.uid() and p.role = 'seller')
)
with check (
  seller_id = auth.uid()
  and exists (select 1 from public.profiles p where p.id = auth.uid() and p.role = 'seller')
);

drop policy if exists "Sellers can delete their own products" on public.products;
create policy "Sellers can delete their own products"
on public.products for delete to authenticated
using (
  seller_id = auth.uid()
  and exists (select 1 from public.profiles p where p.id = auth.uid() and p.role = 'seller')
);

-- Public media: anyone can view the published product images/videos; only seller-owned folders can upload.
insert into storage.buckets (id, name, public, file_size_limit, allowed_mime_types)
values (
  'craft-media',
  'craft-media',
  true,
  20971520,
  array['image/jpeg','image/png','image/webp','image/gif','image/avif','image/heic','video/mp4','video/webm','video/quicktime','video/x-m4v']
)
on conflict (id) do update set
  public = true,
  file_size_limit = 20971520,
  allowed_mime_types = excluded.allowed_mime_types;

drop policy if exists "Public can view CraftStory media" on storage.objects;
create policy "Public can view CraftStory media"
on storage.objects for select to anon, authenticated
using (bucket_id = 'craft-media');

drop policy if exists "Sellers upload CraftStory media to own folder" on storage.objects;
create policy "Sellers upload CraftStory media to own folder"
on storage.objects for insert to authenticated
with check (
  bucket_id = 'craft-media'
  and (storage.foldername(name))[1] = auth.uid()::text
  and exists (select 1 from public.profiles p where p.id = auth.uid() and p.role = 'seller')
);

drop policy if exists "Sellers delete their CraftStory media" on storage.objects;
create policy "Sellers delete their CraftStory media"
on storage.objects for delete to authenticated
using (
  bucket_id = 'craft-media'
  and (storage.foldername(name))[1] = auth.uid()::text
  and exists (select 1 from public.profiles p where p.id = auth.uid() and p.role = 'seller')
);

-- Enable automatic cross-device updates for the marketplace, if not already enabled.
do $$
begin
  if not exists (
    select 1 from pg_publication_tables
    where pubname = 'supabase_realtime' and schemaname = 'public' and tablename = 'products'
  ) then
    alter publication supabase_realtime add table public.products;
  end if;
exception when undefined_object then
  raise notice 'The supabase_realtime publication was not available; enable Realtime for public.products in the dashboard.';
end $$;
